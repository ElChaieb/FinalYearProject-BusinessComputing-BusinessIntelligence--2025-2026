# etl/pipeline/validators/schema_validator.py
"""
Validates sheet structure before any row-level processing.

Column mapping (source → DWH):
  OP sheet:
    Oppo_OpportunityId  → fact_opportunities.oppo_id
    Chan_Description    → fact_opportunities.agency_name  (agencyName)
    User_LastName       → dim_user.last_name
    User_FirstName      → dim_user.first_name
    Oppo_CreatedDate    → fact_opportunities.created_date
    Oppo_AssignedUserId → fact_opportunities.user_id  (FK to dim_user)
    Comp_Name           → dim_client.full_name
    Addr_City           → dim_client.city
    Oppo_Deleted        → fact_opportunities.deleted
    User_EmailAddress   → dim_user.email
    Emai_EmailAddress   → dim_client.email

  DEVIS sheet:
    Quot_opportunityid  → fact_quotes.oppo_id  (FK)
    Quot_OrderQuoteID   → fact_quotes.quote_id  (keep first on dup)
    Marque              → dim_vehicle.brand
    Modèle              → dim_vehicle.model
    Quot_CreatedDate    → fact_quotes.created_date
    AR_Ref              → dim_vehicle.ar_ref  (PK)
    AR_Design           → dim_vehicle.ar_design
    User_LastName       → dim_user.last_name  (fallback)
    User_FirstName      → dim_user.first_name (fallback)
    User_UserId         → dim_user FK (preferred; optional)
"""

# ── Required columns ────────────────────────────────────────────────────────
OP_REQUIRED = {
    "Oppo_OpportunityId",
    "Oppo_CreatedDate",
    "Oppo_AssignedUserId",
    "User_LastName",
    "User_FirstName",
    "User_EmailAddress",
    "Chan_Description",
    "Comp_Name",
}

DEVIS_REQUIRED = {
    "Quot_opportunityid",
    "Quot_OrderQuoteID",
    "AR_Ref",
    "User_LastName",
    "User_FirstName",
}

# ── Optional columns ─────────────────────────────────────────────────────────
# OP optional   : Oppo_Deleted, Addr_City, Emai_EmailAddress,
#                 user_location, comp_reference, Addr_Address1
# DEVIS optional: User_UserId, Quot_CreatedBy, Quot_CreatedDate,
#                 AR_Design, Marque, Modèle


def validate_sheets(df_op, df_devis, filename: str) -> dict:
    """
    Returns:
        {"valid": bool, "errors": [str], "warnings": [str]}
    """
    errors = []
    warnings = []

    # ── Sheet presence ───────────────────────────────────────────────────────
    if df_op is None:
        errors.append("Sheet 'OP' is missing from the file.")
    if df_devis is None:
        errors.append("Sheet 'DEVIS' is missing from the file.")
    if errors:
        return {"valid": False, "errors": errors, "warnings": warnings}

    # ── Empty check ──────────────────────────────────────────────────────────
    if df_op.empty or len(df_op.columns) == 0:
        errors.append("Sheet 'OP' is empty.")
    if df_devis.empty or len(df_devis.columns) == 0:
        errors.append("Sheet 'DEVIS' is empty.")
    if errors:
        return {"valid": False, "errors": errors, "warnings": warnings}

    op_cols    = set(df_op.columns)
    devis_cols = set(df_devis.columns)

    # ── Required column checks ───────────────────────────────────────────────
    missing_op = OP_REQUIRED - op_cols
    if missing_op:
        errors.append(f"Sheet 'OP' is missing required columns: {sorted(missing_op)}")

    missing_devis = DEVIS_REQUIRED - devis_cols
    if missing_devis:
        errors.append(f"Sheet 'DEVIS' is missing required columns: {sorted(missing_devis)}")

    # ── Warnings for optional columns ────────────────────────────────────────
    if not missing_op:
        for col, msg in [
            ("Oppo_Deleted",      "all opportunities will be treated as active"),
            ("Addr_City",         "client city will be NULL"),
            ("Emai_EmailAddress", "client email will be NULL"),
        ]:
            if col not in op_cols:
                warnings.append(f"OP missing '{col}' — {msg}.")

    if not missing_devis:
        if "User_UserId" not in devis_cols:
            warnings.append(
                "DEVIS missing 'User_UserId' — user resolved by (last_name, first_name). "
                "Verify results manually."
            )
        for col in ("Quot_CreatedDate", "AR_Design", "Marque", "Modèle"):
            if col not in devis_cols:
                warnings.append(f"DEVIS missing '{col}' (non-blocking).")

    return {"valid": len(errors) == 0, "errors": errors, "warnings": warnings}
